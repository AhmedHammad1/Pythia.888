// File: hist.cc
// This is a simple test program.
// It studies the charged multiplicity distribution at the LHC.
// Modified by Rene Brun, Axel Naumann and Bernhard Meirose 
// to use ROOT for histogramming.
// Copyright (C) 2013 Torbjorn Sjostrand

// Stdlib header file for input and output.
#include <iostream>

// Header file to access Pythia 8 program elements.
#include "Pythia8/Pythia.h"

// ROOT, for histogramming.
#include "TH1.h"

// ROOT, for interactive graphics.
#include "TVirtualPad.h"
#include "TApplication.h"

// ROOT, for saving file.
#include "TFile.h"
#include "TTree.h"
#include "TBrowser.h"
#include "TRandom.h"
#include <vector>
#include <iostream>
#include <iomanip>








using namespace Pythia8;

int main(int argc, char* argv[]) {

  // Create the ROOT application environment. 
  TApplication theApp("hist", &argc, argv);

 	 // Create Pythia instance and set it up to generate hard QCD processes
  // above pTHat = 20 GeV for pp collisions at 14 TeV.
  Pythia pythia;
   pythia.readString("Beams:frameType = 4"); 
   pythia.readString(" Beams:LHEF = unweighted_events.lhe"); 
   pythia.readString(" PartonLevel:MPI = off"); 
   pythia.readString(" PartonLevel:ISR = off"); 
   pythia.readString(" PartonLevel:FSR = off"); 
   pythia.readString(" HadronLevel:Hadronize  = off"); 
   pythia.readString(" HadronLevel:Decay = off"); 
   pythia.readString(" ProcessLevel:resonanceDecays = off");	
   pythia.readString(" PartonLevel:Remnants = off"); 
	 pythia.init();
  
  // Create Tree  on which histogram(s) can be saved.
  TFile *f = new TFile("H.root","RECREATE"); 
  TTree *t1 = new TTree("T","Analysis");
  
  vector<double> Eta; vector<double> PT; vector<double> Phi; vector<double> En; vector<double> Px;
  vector<double> Py; vector<double> Pz; vector<double> Ma;vector<double> Scale;
  vector<int> pdgId;vector<int> Mother1; vector<int> Status;

  UInt_t          EventNumber;
  // Create Branches
  t1->Branch("EventNumber",&EventNumber,"EventNumber/I");
  t1->Branch("Eta",&Eta);
  t1->Branch("PT",&PT);
  t1->Branch("Phi",&Phi);
  t1->Branch("En",&En);
  t1->Branch("Px",&Px);
  t1->Branch("Py",&Py);
  t1->Branch("Pz",&Pz);
  t1->Branch("Ma",&Ma);
  t1->Branch("Scale",&Scale);

  t1->Branch("Mother1",&Mother1);
  t1->Branch("pdgId",&pdgId);
  t1->Branch("Status",&Status);
  
  
  
  // Begin event loop. Generate events; skip if generation aborted.
  for (int iEvent = 0; ; ++iEvent) {
    pdgId.clear();
    Eta.clear();
    PT.clear();
    Phi.clear();
    En.clear();
    Px.clear();
    Py.clear();
    Pz.clear();
    Ma.clear();
    Status.clear();
    Scale.clear();
    Mother1.clear();

    if (!pythia.next()) {
      //event=pythia.event.size();
      if (pythia.info.atEndOfFile()) break; 
    }
        
    EventNumber=iEvent;
   //  cout<<"NO=\t"<< EventNumber<<endl;
     pythia.event.list();
    // loop over all particles.         
    for (int i = 0; i < pythia.event.size(); ++i) 
    
     if (abs(pythia.event[i].isFinal()))  
      {
	
	pdgId.push_back(pythia.event[i].id());
         Eta.push_back(pythia.event[i].eta());
	 PT.push_back(pythia.event[i].pT());
	 Phi.push_back(pythia.event[i].phi());
	 En.push_back(pythia.event[i].e());
	 Px.push_back(pythia.event[i].px());
	 Py.push_back(pythia.event[i].py());
	 Pz.push_back(pythia.event[i].pz());
	 Ma.push_back(pythia.event[i].m());
	 Status.push_back(pythia.event[i].status());
	 Scale.push_back(pythia.event[i].scale());
	 Mother1.push_back(pythia.event[i].mother1());   	    
	 // cout<<"NO=\t"<<EventNumber<<setw(10)<<"i=\t"<<i<<setw(10)<<"PDGID=\t"<<(pythia.event[i].id())<<endl;

      } 
 t1->Fill();
  }
  
  
  
  // Statistics on event generation.
  pythia.stat();
  // Save histogram on file and close file.
  //t1->Write();
  f->Write();
  delete f;
  return 0;
}
