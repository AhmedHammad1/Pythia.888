#!/bin/sh
if [ ! $?LD_LIBRARY_PATH ]; then
  export LD_LIBRARY_PATH=/afs/cern.ch/sw/lcg/external/HepMC/2.06.08/x86_64-slc5-gcc41-opt/lib
fi
if [ $?LD_LIBRARY_PATH ]; then
  export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:/afs/cern.ch/sw/lcg/external/HepMC/2.06.08/x86_64-slc5-gcc41-opt/lib
fi
export PYTHIA8DATA=${PYTHIA8_HOME}/xmldoc
